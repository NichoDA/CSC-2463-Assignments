function setup(){
    createCanvas(410,200);
    background ('#39FF14');
}

function draw(){
    ellipse(100, 100, 175, 175);
    square(220, 18, 170);
}